<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' href='admin-style.css'>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>360 Faculty Evaluation System</title>

    <nav class="topnav">

    </nav>
</head>

<body>
    <div class='container'>
        <!-- side section -->
        <aside>
            <div class="sidepanel">
                <div class="top">
                    <div class="logo">
                        <img src="\360EvaluationSystem\LPU_CAVITE-logo.png" width="90" height="auto">
                        <!-- <h2>C<span class="danger">BABAR</span></h2> -->
                    </div>
                </div>
                <!-- end of top side -->

                <div class="sidebar">
                    <a href="admin-dashboard.php">
                        <span class="material-symbols-outlined">
                            <img src="icons/dashboard.jpg">
                        </span>
                        <h3>Dashboard</h3>
                    </a>
                    <a href="admin-courses.php">
                        <span class="material-symbols-outlined">
                            <img src="icons/course.jpg">
                        </span>
                        <h3>Course</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/program.jpg">
                        </span>
                        <h3>Program</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/section.jpg">
                        </span>
                        <h3>Section</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/students.jpg">
                        </span>
                        <h3>Students</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/departments.jpg">
                        </span>
                        <h3>Departments</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/faculty.jpg">
                        </span>
                        <h3>Faculty</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/accounts.jpg">
                        </span>
                        <h3>Accounts</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/evaluations.jpg">
                        </span>
                        <h3>Evaluations</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/reports.jpg">
                        </span>
                        <h3>Reports</h3>
                    </a>
                    <a href="#">
                        <span class="material-symbols-outlined">
                            <img src="icons/signout.jpg">
                        </span>
                        <h3>Sign Out</h3>
                    </a>
                </div>
            </div>

        </aside>

        <!-- side section ends -->

        <!-- main section start -->
        <main>
            <div class="upperMain">
                <h1>Courses</h1>
            </div>
            <div class="content">

            </div>
        </main>

        <!-- main section ends -->

    </div>
</body>

</html>